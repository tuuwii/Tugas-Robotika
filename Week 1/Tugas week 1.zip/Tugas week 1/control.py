from controller import Robot, Motor

# Buat instance Robot
robot = Robot()

# Dapatkan timestep dunia saat ini
timestep = int(robot.getBasicTimeStep())

# Mengambil perangkat motor untuk roda kiri dan kanan
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')

# Atur mode posisi motor ke infinity untuk rotasi terus-menerus
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

# Mengatur kecepatan awal motor
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Mengambil sensor jarak inframerah (8 sensor pada e-puck)
ps = []
ps_names = [
    'ps0', 'ps1', 'ps2', 'ps3',
    'ps4', 'ps5', 'ps6', 'ps7'
]

# Mengaktifkan semua sensor jarak
for i in range(8):
    ps.append(robot.getDevice(ps_names[i]))
    ps[i].enable(timestep)

# Kecepatan motor
forward_speed = 5.0
backward_speed = -2.0
turn_speed = 4.0

# Loop utama: jalankan hingga Webots menghentikan controller
while robot.step(timestep) != -1:
    # Membaca nilai dari semua sensor jarak
    ps_values = [sensor.getValue() for sensor in ps]

    # Logika penghindaran rintangan
    right_obstacle = ps_values[0] > 80.0 or ps_values[1] > 80.0 or ps_values[2] > 80.0
    left_obstacle = ps_values[5] > 80.0 or ps_values[6] > 80.0 or ps_values[7] > 80.0

    if right_obstacle:  # Jika ada rintangan di kanan
        # Mundur
        left_motor.setVelocity(backward_speed)
        right_motor.setVelocity(backward_speed)
        robot.step(timestep)  # Menunggu sejenak untuk mundur

        # Putar balik ke kiri
        left_motor.setVelocity(-turn_speed)
        right_motor.setVelocity(turn_speed)
        robot.step(100)  # Putar selama 100ms (disesuaikan)

    elif left_obstacle:  # Jika ada rintangan di kiri
        # Mundur
        left_motor.setVelocity(backward_speed)
        right_motor.setVelocity(backward_speed)
        robot.step(timestep)  # Menunggu sejenak untuk mundur

        # Putar balik ke kanan
        left_motor.setVelocity(turn_speed)
        right_motor.setVelocity(-turn_speed)
        robot.step(100)  # Putar selama 100ms (disesuaikan)

    else:
        # Tidak ada rintangan, maju terus
        left_motor.setVelocity(forward_speed)
        right_motor.setVelocity(forward_speed)

# Cleanup saat keluar dari loop
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)
